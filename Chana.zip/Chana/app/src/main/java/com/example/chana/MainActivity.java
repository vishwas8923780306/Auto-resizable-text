package com.example.chana;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText edt;
TextView tv;
Float a=80.00f;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edt=findViewById(R.id.edittext);
        tv=findViewById(R.id.textview);
        edt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                tv.setTextSize(a);
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                a=a-5;
                tv.setTextSize(a);
                tv.setText(s);

            }

            @Override
            public void afterTextChanged(Editable s) {

                if(a<16)
                {
                    tv.append("\n");
                    a=80f;
                }
            }


                    });



    }
}
